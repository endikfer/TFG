using UnityEngine;

public class Meta4 : MonoBehaviour
{
    // Ambos son parte del circuito → singleton disponible en Start
    private Agente4 kartAgent;
    private CheckPointsManager3 manager;

    private void Start()
    {
        manager = CheckPointsManager3.Instance;

        // El agente puede no estar aún → esperamos su evento
        if (Agente4.Instance != null)
            kartAgent = Agente4.Instance;
        else
            Agente4.OnAgentReady += OnAgentReady;
    }

    private void OnDestroy()
    {
        Agente4.OnAgentReady -= OnAgentReady;
    }

    private void OnAgentReady()
    {
        kartAgent = Agente4.Instance;
        Agente4.OnAgentReady -= OnAgentReady;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (kartAgent == null || manager == null) return;

        if (manager.GetCheckpointIndex() == manager.checkpp.checkPoints.Count)
            kartAgent.ScoredAGoal();
    }
}
