using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

/// <summary>
/// Escucha el evento OnCircuitoCerrado y guarda el circuito en un archivo JSON
/// en Application.persistentDataPath/Circuitos/
/// </summary>
public class CircuitoSaver : MonoBehaviour
{
    [Header("Configuración de guardado")]
    [Tooltip("Subcarpeta dentro de persistentDataPath donde se guardarán los circuitos")]
    public string carpetaGuardado = "Circuitos";

    [Tooltip("Prefijo del nombre de archivo. Se añadirá un timestamp automáticamente.")]
    public string prefijioArchivo = "circuito";

    [Header("Debug")]
    public bool mostrarLogs = true;

    // ── Modelos de datos serializables ──────────────────────────────────────

    [Serializable]
    private class DatosPieza
    {
        public string tipo;
        public float px, py, pz;   // posición world
        public float rx, ry, rz;   // rotación euler
    }

    [Serializable]
    private class DatosCircuito
    {
        public string fecha;
        public float distanciaTotal;
        public int numeroPiezas;
        public List<DatosPieza> piezas = new List<DatosPieza>();
    }

    // ── Unity lifecycle ─────────────────────────────────────────────────────

    private void OnEnable()
    {
        CircuitoEventos.OnCircuitoCerrado += HandleCircuitoCerrado;
    }

    private void OnDisable()
    {
        CircuitoEventos.OnCircuitoCerrado -= HandleCircuitoCerrado;
    }

    // ── Handler ─────────────────────────────────────────────────────────────

    private void HandleCircuitoCerrado(List<PiezaCircuito> piezas, float distanciaTotal)
    {
        GuardarCircuito(piezas, distanciaTotal);
    }

    // ── Lógica de guardado ──────────────────────────────────────────────────

    private void GuardarCircuito(List<PiezaCircuito> piezas, float distanciaTotal)
    {
        // Construir el modelo de datos
        DatosCircuito datos = new DatosCircuito
        {
            fecha         = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            distanciaTotal = distanciaTotal,
            numeroPiezas  = piezas.Count
        };

        foreach (PiezaCircuito pieza in piezas)
        {
            Vector3 pos    = pieza.transform.position;
            Vector3 euler  = pieza.transform.eulerAngles;

            datos.piezas.Add(new DatosPieza
            {
                tipo = pieza.tipo.ToString(),
                px   = pos.x,   py = pos.y,   pz = pos.z,
                rx   = euler.x, ry = euler.y, rz = euler.z
            });
        }

        // Serializar a JSON
        string json = JsonUtility.ToJson(datos, prettyPrint: true);

        // Preparar ruta
        string directorioBase = Path.Combine(Application.persistentDataPath, carpetaGuardado);

        if (!Directory.Exists(directorioBase))
            Directory.CreateDirectory(directorioBase);

        // Nombre único con timestamp
        string timestamp   = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string nombreArchivo = $"{prefijioArchivo}_{timestamp}.json";
        string rutaCompleta  = Path.Combine(directorioBase, nombreArchivo);

        // Escribir
        File.WriteAllText(rutaCompleta, json);

        if (mostrarLogs)
        {
            Debug.Log($"💾 Circuito guardado:\n" +
                      $"   Archivo : {nombreArchivo}\n" +
                      $"   Ruta    : {rutaCompleta}\n" +
                      $"   Piezas  : {datos.numeroPiezas}\n" +
                      $"   Distancia: {distanciaTotal:F1}m");
        }
    }

    // ── Utilidad: listar circuitos guardados ────────────────────────────────

    /// <summary>
    /// Devuelve todas las rutas de circuitos guardados, ordenadas por fecha (más reciente primero).
    /// Útil para implementar un selector de circuitos guardados.
    /// </summary>
    public string[] ObtenerCircuitosGuardados()
    {
        string directorio = Path.Combine(Application.persistentDataPath, carpetaGuardado);

        if (!Directory.Exists(directorio))
            return Array.Empty<string>();

        string[] archivos = Directory.GetFiles(directorio, "*.json");
        Array.Sort(archivos, (a, b) => File.GetLastWriteTime(b).CompareTo(File.GetLastWriteTime(a)));

        return archivos;
    }
}
