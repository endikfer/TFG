using UnityEngine;

public class CocheContacto5 : MonoBehaviour
{
    // Este script está en el coche, que carga después del circuito.
    // El agente está en el mismo GameObject o en su padre → búsqueda local, coste cero.
    private Agente4 karAgent;

    private void Awake()
    {
        // Primero intenta en el mismo GameObject y sus padres/hijos (coste mínimo)
        karAgent = GetComponentInParent<Agente4>();

        if (karAgent == null)
            karAgent = GetComponentInChildren<Agente4>();

        // Si por alguna razón no está en la jerarquía local, usar el singleton
        if (karAgent == null)
            karAgent = Agente4.Instance;

        if (karAgent == null)
            Debug.LogError("[CocheContacto5] No se encontró Agente4.");
    }

    private void OnCollisionEnter(Collision col)
    {
        if (karAgent != null)
            karAgent.salidaDePista = true;
    }

    private void OnCollisionExit(Collision collision)
    {
        if (karAgent != null)
            karAgent.salidaDePista = false;
    }
}
